const form = document.querySelector("form");

window.addEventListener("load", () => {
    //adicionando classe criada no css ao form
    form.classList.add("formStyle");

    //Criando titulo e adicionando ao form
    let titulo = document.createElement("h1");
    form.appendChild(titulo);
    titulo.textContent = "Login";

    //Criando o inputEmail com seus atributos como pedido no exercício
    let inputEmail = document.createElement("input");
    form.appendChild(inputEmail)
    inputEmail.setAttribute("placeholder", "EMAIL");
    inputEmail.setAttribute("type", "email");
    inputEmail.disabled = true;
    inputEmail.removeAttribute("placeholder", "EMAIL");

    //Criando o inputSenha com seus atributos como pedido no exercício
    let inputSenha = document.createElement("input");
    form.appendChild(inputSenha)
    inputSenha.setAttribute("placeholder", "SENHA");
    inputSenha.setAttribute("type","password")

    //Criando o botao de cancelar
    let btnCancelar = document.createElement("button");
    form.appendChild(btnCancelar);
    btnCancelar.textContent = "Cancelar";

    //Criando o botao de enviar
    let btnSubmit = document.createElement("button");
    form.appendChild(btnSubmit);
    btnSubmit.textContent = "Enviar";
})