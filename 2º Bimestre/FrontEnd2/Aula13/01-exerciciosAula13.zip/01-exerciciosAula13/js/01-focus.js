let txtNome = document.querySelector('#txtNome');
txtNome.focus();
document.getElementById("txtNome").style.background = "yellow";