

document.addEventListener('click', (alerta) => {
    alert('Olá!!!');
});