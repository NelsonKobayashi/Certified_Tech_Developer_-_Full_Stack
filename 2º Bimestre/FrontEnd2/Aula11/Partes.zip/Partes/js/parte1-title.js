/* Template strings
são strings que permitem expressões embutidas. 
Você pode utilizar string multi-linhas e 
interpolação de string com elas.*/
//Função para a criação de cards
let title = ""



function criarCard() {
    title = document.getElementById("title").value
   
    let cardSection = document.getElementById("card");
    cardSection.innerHTML += `<div><h2>${title}</h2></div>`;
}