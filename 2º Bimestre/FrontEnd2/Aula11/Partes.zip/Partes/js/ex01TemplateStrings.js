let nome = "José";
let sobrenome = "Silva";

let frase = `Bem vindo usuário, ${nome} ${sobrenome}!`;

document.getElementById("paragrafo").innerHTML = frase;