//Função para a criação de cards
let urlImg = ""

function createCard() {

    urlImg = document.getElementById("url_img").value


    let cardSection = document.getElementById("card");
    cardSection.innerHTML += `<div> <img src="${urlImg}"></div>`;
}