//Aula 10 - 23/06/2021

let pessoa = {
    nome: 'William',
    idade: 53,
    sexo: 'm',
    filho: 2
}
let cachorro = {
    nome: 'Theodor',
    idade: 53,
    sexo: 'm',
    filho: 2
}
module.exports = {pessoa,cachorro};