let cachorro = {
    nome: 'Theodor',
    idade: 3,
    sexo: 'm',
    filho: 0
}
module.exports = cachorro;