// 23/06/2021
// 
const calculadora = require('./modulos/ex02ExpFuncoes');

//console.log(calculadora.somar(2,2));
// console.log(calculadora.subtrair(2,2));
// console.log(calculadora.multiplicar(2,2));
console.log(calculadora.dividir(2,0));
//==
//calculadora.maiuscula('william');



