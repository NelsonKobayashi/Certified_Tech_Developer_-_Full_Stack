//Aula 10 - 23/06/2021

const {pessoa, cachorro} = require('./modulos/ex01Exp');

console.log(pessoa.nome);
console.log(cachorro.cor);