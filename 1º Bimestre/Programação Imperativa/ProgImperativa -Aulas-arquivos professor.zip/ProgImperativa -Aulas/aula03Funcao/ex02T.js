//Aula 03 - 01/06/2021
//Revisão de variáveis
nome = "William"; // string (texto)
idade = 53; // número inteiro (int)
peso = 83.5 // número com ponto flutuante ou casas decimais
temFaculdade = true; // lógico -> verdadeiro ou falso
ehFeioDemais = false;

//console.log(typeof nome, typeof idade, typeof peso, typeof temFaculdade, typeof ehFeioDemais);
//console.log(typeof(nome, idade, peso, temFaculdade, ehFeioDemais));
console.log(typeof idade);
console.log(typeof peso);
console.log(typeof temFaculdade);
console.log(typeof ehFeioDemais);