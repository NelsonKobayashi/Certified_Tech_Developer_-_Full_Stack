function teste2(x, y) {
    return x * 2
    console.log(x)
    return x / 2
}

teste2(10)




// //Aula 03 - 01/06/2021
// //Revisão de variáveis

// function minhaFuncao1() {
//     console.log("Minha Primeira Função");
// }

// //chamando a função
// minhaFuncao1();
