//Aula 03 - 01/06/2021
//Revisão de variáveis

function minhaFuncao2(a, b) {
   return  a * b;
}

//chamando a função
resultado = minhaFuncao2(4, 3);
console.log(resultado);