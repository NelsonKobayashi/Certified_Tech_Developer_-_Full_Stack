//Aula 03 - 01/06/2021
//Revisão de variáveis
nome = "William"; // string (texto)
idade = 53; // número inteiro (int)
peso = 83.5 // número com ponto flutuante ou casas decimais
temFaculdade = true; // lógico -> verdadeiro ou falso
ehFeioDemais = false;

console.log(nome);
console.log(idade);
console.log(peso);
console.log(temFaculdade);
console.log(ehFeioDemais);