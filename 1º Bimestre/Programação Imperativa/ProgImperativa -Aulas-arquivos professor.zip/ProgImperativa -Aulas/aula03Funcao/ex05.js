//Aula 03 - 01/06/2021
//Function

let idade = 25; //valor inicial

function alteraIdade() {
    idade++;
    console.log(idade);
    return idade;
}
alteraIdade();
alteraIdade();
alteraIdade();
alteraIdade();
alteraIdade();