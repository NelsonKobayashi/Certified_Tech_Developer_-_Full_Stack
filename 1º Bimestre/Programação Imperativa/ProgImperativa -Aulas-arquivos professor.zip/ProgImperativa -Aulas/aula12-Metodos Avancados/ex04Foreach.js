// aula 12 - 06/07/2021
// ex04Foreach.js
// forEach = para cada um elemento
// O forEach() é um método chama uma função uma vez para cada elemento
// em um array.

let pizza = ['pedaço1','pedaço2','pedaço3','pedaço4'];

pizza.forEach(
  function(pedaco) {
      console.log(pedaco);
  }  
) 

