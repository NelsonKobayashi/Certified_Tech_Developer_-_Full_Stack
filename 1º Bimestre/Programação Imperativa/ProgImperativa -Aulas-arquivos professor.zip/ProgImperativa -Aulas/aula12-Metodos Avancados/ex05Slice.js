// aula 12 - 06/07/2021
// ex04Foreach.js
// slice = fatiar
/* O método array.slice(), retorna os elementos selecionados da matriz,
sintaxe: array.slice(ínicio, fim)*/
                   //0        //1    //2      //3      //4
const frutas = ['Banana',"Laranja", "Limão", "Maçã", "Manga"];
const citricas = frutas.slice(0,4); // começa no x e finaliza no x
console.log(citricas);