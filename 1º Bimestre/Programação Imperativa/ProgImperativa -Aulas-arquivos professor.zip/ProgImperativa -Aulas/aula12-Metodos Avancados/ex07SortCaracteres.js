// ex07Sort.js
// Sort = ordenar
// array.sort() nos ajuda a ordenar os elementos de uma array

const frutas = ["Maçã","Banana","Acerola", "Limão", "Abacate"];
frutas.sort();
console.log(frutas);
