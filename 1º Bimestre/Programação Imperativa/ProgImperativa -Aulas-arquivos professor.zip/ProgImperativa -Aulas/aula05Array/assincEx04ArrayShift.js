// C5A - Aula 05 - Assíncrona

let cores = ["Azul","Branco","Vermelho","Verde"];
console.log(cores.length);
console.log(cores);

console.log("**********shift************");

cores.shift(); //O shift, remove do array o elemento no índice "0";
//início do array

console.log(cores);
console.log(cores.length);
