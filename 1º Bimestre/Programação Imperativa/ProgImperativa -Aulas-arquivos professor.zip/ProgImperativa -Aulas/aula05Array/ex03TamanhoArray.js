//Aula 05 - 07/06/2021
// Arrays - Posição dentro de um array
let filmesFavoritos = ['Star Trek', 'De Volta para o Futuro', 'The Passenger'];
console.log(filmesFavoritos.length); // retorna 3 (número de elementos)




