// Aula 05 - 07/06/2021
// Array - Método Pop --> Retirar o último elemento do Array
let cores = ["Azul","Branco","Vermelho", "Verde"];
console.log(cores);
//console.log(cores.length);

//pop
let ultimoElemento = cores.pop();
console.log(cores);
console.log(ultimoElemento);

console.log(cores.length);
console.log(cores[4]);
