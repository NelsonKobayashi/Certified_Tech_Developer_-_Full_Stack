
//localiza um elemento dentro array
let cores = ["Azul","Branco","Vermelho","Verde"];
console.log(cores.indexOf("Vermelh")); //localiza a posição de "vermelho" no array

// se não localizar, exibirá -1
//Faz diferença entre maiúsculas e minúsculas Vermelho <> vermelho


