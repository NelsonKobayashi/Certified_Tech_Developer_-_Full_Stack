// pop _>  para retirar elementos do array
// push para inserir elementos no final do array
// shift para retirar elementos no início de um array
// unshift para inserir elementos no início de um array
// indexOf e lastIndexOf para perguntar o índice de ocorrência de um elemento
// join para unir todos os elementos presentes em um array