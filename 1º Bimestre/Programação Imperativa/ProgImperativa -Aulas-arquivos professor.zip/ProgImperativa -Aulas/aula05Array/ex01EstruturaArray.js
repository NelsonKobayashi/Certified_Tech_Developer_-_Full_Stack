//Aula 05 - 07/06/2021
// Arrays - Estrutura
let meuArray = ['Star Trek', 'De Volta para o Futuro', 'O Homem Bicentenário'];
console.log(meuArray);