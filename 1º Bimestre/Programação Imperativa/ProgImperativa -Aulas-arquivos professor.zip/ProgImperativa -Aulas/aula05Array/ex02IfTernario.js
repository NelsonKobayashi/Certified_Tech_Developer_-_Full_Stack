// Aula 05 - 07/06/2021
// Condicional - IF TERNÁRIO

let idade = 17
//
console.log(idade>=18) ? "Maior de Idade" : "Menor de Idade"
