// C5A - Aula 05 - Assíncrona
// Array ---> adicionar um ou mais elementos do Array
let cores = ["Azul","Branco","Vermelho", "Verde"];

cores.push("Violeta", "Amarelo");

console.log(cores);
console.log(cores.length);