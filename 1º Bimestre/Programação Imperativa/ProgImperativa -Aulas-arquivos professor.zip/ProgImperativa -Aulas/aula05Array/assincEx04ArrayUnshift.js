// C5A - Aula 05 - Assíncrona
// Array ---> adicionar um ou mais elementos do Array
let cores = ["Azul","Branco","Vermelho","Verde"];
console.log(cores.length);
console.log(cores);

console.log("**********unshift************");

cores.unshift("Violeta","Amarelo"); //O unshift, insere um ou mais dados ao
//início do array

console.log(cores);
console.log(cores.length);
