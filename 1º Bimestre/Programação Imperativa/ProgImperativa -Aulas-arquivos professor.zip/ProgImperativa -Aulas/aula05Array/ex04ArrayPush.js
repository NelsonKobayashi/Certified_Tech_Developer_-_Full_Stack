// Aula 05 - 07/06/2021
// Array - Método Push --> Inserir elementos no final do array
let cores = ["Azul","Branco","Vermelho", "Verde"];

console.log(cores);
// push
cores.push("Violeta", "Amarelo");
console.log(cores);