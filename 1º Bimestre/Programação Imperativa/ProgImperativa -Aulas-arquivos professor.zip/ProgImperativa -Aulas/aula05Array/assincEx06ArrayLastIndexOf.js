
//localiza um elemento dentro array
let cores = ["Vermelho","Branco","Vermelho","Verde"];
console.log(cores.indexOf("Vermelho")); //localiza a posição de "vermelho" no array

// se não localizar, exibirá -1
//Faz diferença entre maiúsculas e minúsculas Vermelho <> vermelho
console.log(cores.lastIndexOf("Vermelho"));