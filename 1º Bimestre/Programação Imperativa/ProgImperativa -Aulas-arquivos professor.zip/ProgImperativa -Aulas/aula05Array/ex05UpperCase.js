// criar este array
let filmes = ["Star Trek", "Star Wars", "Passenger", "O Homem Bicentenário"];
 
let letrasMaiusculas = filmes.map(filme => filme.toUpperCase());
 
console.log(letrasMaiusculas);