// C5A - Aula 05 - Assíncrona
// Array 
let pessoa = ['William', 53, 1.69, true, ["Pão de Queijo","café"]];
console.log(pessoa);
console.log(pessoa[4]);
console.log(pessoa.length);