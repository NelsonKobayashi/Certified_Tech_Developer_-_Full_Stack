
//localiza um elemento dentro array
let diasDaSemana = ["Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira", "Sexta-feira", "Sábado", "Domingo"];
console.log(diasDaSemana.join());
// ou substituir o vírgula por traço
console.log(diasDaSemana.join(" - "));

