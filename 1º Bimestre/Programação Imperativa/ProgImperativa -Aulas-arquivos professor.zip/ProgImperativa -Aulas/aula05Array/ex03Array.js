// Aula 05 - 07/06/2021
// Array 
let pessoa = ['William', 53, 1.7, true]
//console.log(pessoa)
//console.log(pessoa[0]); // exibir o conteúdo do índice
console.log(pessoa.length); // exibir o tamanho do array