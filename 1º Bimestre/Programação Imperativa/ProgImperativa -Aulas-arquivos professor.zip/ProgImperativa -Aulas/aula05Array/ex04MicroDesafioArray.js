// criar este array
let filmes = [
    "star wars",
    "clube da luta",
    "o poderoso chefão",
    "top gun",
    "interestelar",
   ];
   
   // ***********************************
   // **            Item 1            **
   // ***********************************
   
   console.log(" O segundo elemento do array é: " + filmes[1]);
   
   // ***********************************
   // **            Item 2            **
   // ***********************************
   
   console.log("----------- Item 2 ------------");
   
   
   const arrayToUpperCase = function (array, index) {
    allfilmes[index] = array[index].toUpperCase();
   };
   
   console.log(filmes);
   let allfilmes = [];
   arrayToUpperCase(filmes, 0);
   arrayToUpperCase(filmes, 1);
   arrayToUpperCase(filmes, 2);
   arrayToUpperCase(filmes, 3);
   arrayToUpperCase(filmes, 4);
   console.log(allfilmes);
   
   