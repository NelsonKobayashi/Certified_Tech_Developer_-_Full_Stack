// C5A - Aula 05 - Assíncrona
// Array ---> adicionar um ou mais elementos do Array
let cores = ["Azul","Branco","Vermelho","Verde","Violeta","Amarelo"];
console.log(cores);
console.log(cores.length);

let ultimoElemento = cores.pop(); 
// retira o último elemento do array e tb armazena

console.log(cores);
console.log(cores.length);
console.log(ultimoElemento);