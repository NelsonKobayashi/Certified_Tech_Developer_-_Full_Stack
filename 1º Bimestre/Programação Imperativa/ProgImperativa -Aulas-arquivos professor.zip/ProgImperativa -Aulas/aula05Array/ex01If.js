// Aula 05 - 07/06/2021
// Condicional - IF

let idade = 18

if(idade >=18) {
    console.log("Maior de Idade")
} else {
    console.log("Menor de Idade")
}
