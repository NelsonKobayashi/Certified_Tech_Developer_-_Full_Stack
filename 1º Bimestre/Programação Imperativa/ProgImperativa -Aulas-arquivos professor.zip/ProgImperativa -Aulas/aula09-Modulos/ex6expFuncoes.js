exports.mais=(a,b)=>a+b;

exports.menos=(a,b)=>a-b;

exports.maiuscula=(texto)=>console.log(texto.toUpperCase());


