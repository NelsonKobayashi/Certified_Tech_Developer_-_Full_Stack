const mais=require('./modulos/ex6expFuncoes');
const menos=require('./modulos/ex6expFuncoes');
const maiuscula=require('./modulos/ex6expFuncoes');

console.log(mais.mais(2,3))
console.log(menos.menos(20,3))
maiuscula.maiuscula('silvia');
mais.maiuscula('aaa');





