// Aula 09 - Módulos
// Fora da Pasta Modulos

let familia = require('./modulos/ex02Export'); //importação

console.log(familia.pessoa);
console.log(familia.pessoa.nome);
console.log(familia.pessoa.idade);

console.log(familia.cachorro);
console.log(familia.cachorro.nome1);
console.log(familia.cachorro.raca1);

