//utilizando o módulo criado no ex1.js

let cumprimento = require('./modulos/ex1.js');  //importação
cumprimento=cumprimento+' William';
console.log(cumprimento);

