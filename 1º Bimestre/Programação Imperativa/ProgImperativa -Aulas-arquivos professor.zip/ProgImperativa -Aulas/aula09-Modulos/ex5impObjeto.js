let pessoa=require('./modulos/ex5.js');
console.log(pessoa);
console.log(pessoa.nome);