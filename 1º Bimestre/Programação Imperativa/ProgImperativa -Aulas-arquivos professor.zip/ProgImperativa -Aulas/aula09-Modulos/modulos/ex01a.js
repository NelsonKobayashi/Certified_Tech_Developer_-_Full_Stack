// Aula 09 - Módulos
// Dentro da Pasta Modulos

let pessoa = {
    nome: 'William',
    idade: 53,
    sexo: 'm',
    filho: 2
}
module.exports=pessoa;
