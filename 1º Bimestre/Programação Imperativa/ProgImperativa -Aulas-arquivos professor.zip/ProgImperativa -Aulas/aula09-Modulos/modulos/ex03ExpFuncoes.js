// objetivo criem funções de cálculo e exportem
//dentro da pasta modulo
//ex03ExpFuncoes.js

// ex03ImpFuncoes.js
