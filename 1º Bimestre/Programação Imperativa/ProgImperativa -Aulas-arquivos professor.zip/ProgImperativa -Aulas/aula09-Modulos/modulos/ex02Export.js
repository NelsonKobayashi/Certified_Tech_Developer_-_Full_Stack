// Aula 09 - Módulos
// Dentro da Pasta Modulos

let pessoa = {
    nome: 'William',
    idade: 53,
    sexo: 'm',
    filho: 2
}

let cachorro = {
    nome1: 'Theodor',
    idade1: 3,
    raca1: 'Maltês Branco',
    sexo1: 'm'    
}
module.exports={pessoa, cachorro};
