//ex1.js
let cumprimento='Bom dia';
cumprimento=cumprimento.toUpperCase();
console.log(cumprimento);


module.exports=cumprimento;

