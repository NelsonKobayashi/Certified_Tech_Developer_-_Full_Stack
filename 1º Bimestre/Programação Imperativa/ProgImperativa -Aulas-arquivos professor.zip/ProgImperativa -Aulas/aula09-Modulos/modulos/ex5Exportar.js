//ex5
let pessoa={nome: 'William',
	idade: 53,
	sexo: 'm',
	filhos: 2}

    module.exports=pessoa;

  

