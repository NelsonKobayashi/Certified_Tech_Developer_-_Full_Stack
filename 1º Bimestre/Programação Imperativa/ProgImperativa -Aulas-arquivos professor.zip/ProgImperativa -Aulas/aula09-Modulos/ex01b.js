// Aula 09 - Módulos
// Fora da Pasta Modulos

let pessoa = require('./modulos/ex01a'); //importação

console.log(pessoa.nome);
console.log(pessoa.idade);
console.log(pessoa.sexo);
console.log(pessoa.filho);
