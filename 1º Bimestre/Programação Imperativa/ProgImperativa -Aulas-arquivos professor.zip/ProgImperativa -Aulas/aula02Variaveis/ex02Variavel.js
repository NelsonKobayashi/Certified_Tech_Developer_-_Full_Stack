// Aula de Variáveis - 28/05/2021
// Concatenação  - Usado paa unir textos (string)

let melhorTime = "Timão";
let temMundial = "Sim!!";

let timeComMundial = melhorTime+" "+temMundial; // Timão Sim!!

console.log("****************************");
console.log(timeComMundial);
console.log("****************************");


