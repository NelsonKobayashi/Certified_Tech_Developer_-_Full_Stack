/* Data: 28/05/2021
 Aula 02 - Variáveis */
 // Comentário em uma linha

 minhaPrimeiraVariavel = "Hello World!!!";
 console.log(minhaPrimeiraVariavel);