//Aula 06 - 09/06/2021
// Repetições - For
// Início do contador / Limite de repetições / Modificador do Contador

for(let i = 0; i<5; i++){
   console.log("Olá Mundo!"); 
 }