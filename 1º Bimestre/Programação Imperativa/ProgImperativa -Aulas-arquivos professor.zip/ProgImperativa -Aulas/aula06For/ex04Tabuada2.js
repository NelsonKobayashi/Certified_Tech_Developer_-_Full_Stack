for (let multiplicado = 1; multiplicado <= 10; multiplicado++) {
 for (let multiplicando = 1; multiplicando <= 10; multiplicando++) {
      console.log(multiplicado + "x" + multiplicando + " = " + 
      (multiplicado * multiplicando))
      }
    console.log("---------------")
}