// Aula 06 - 09/06/2021

const idades = [5, 10, 30, 25, 15, 80, 7, 14, 4, 90];

for(let indice = 0; indice < idades.length; indice++) {
    console.log(idades[indice]);
}



//console.log(idades);
//console.log(idades.length);