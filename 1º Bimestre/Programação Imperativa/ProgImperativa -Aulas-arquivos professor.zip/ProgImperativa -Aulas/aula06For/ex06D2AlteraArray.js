const precoSemTaxa = [1200, 340, 560, 30400, 500, 80, 1000, 90000];
const taxa = 1.21;
for (let i = 0; i < precoSemTaxa.length; i++) {
 console.log(precoSemTaxa[i] * taxa);
}
console.log(precoSemTaxa.length);