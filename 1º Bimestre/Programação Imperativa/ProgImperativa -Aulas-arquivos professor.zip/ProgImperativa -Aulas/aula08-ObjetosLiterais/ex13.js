//spread com funções
let numeros=[10,2,33,14,511,6,7,8];

//utilizando spread operador para mostrar através da função min e max o maior valor e o menor valor

console.log('Maior número:',Math.max(...numeros));
console.log('Menor número:', Math.min(...numeros));

