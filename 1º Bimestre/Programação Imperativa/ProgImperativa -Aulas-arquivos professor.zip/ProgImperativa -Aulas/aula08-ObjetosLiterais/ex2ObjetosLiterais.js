let pessoa={
    //propriedades
	nome: 'Silvia',
	idade: 54,
	sexo: 'f',
	filhos: 2,
    //método
    imprimeEmpresa: function() {return 'Meu nome é '+pessoa.nome+', tenho '+pessoa.filhos +' filhos e sou enfermeira chefe no HMT'}};

    console.log(pessoa.imprimeEmpresa());
