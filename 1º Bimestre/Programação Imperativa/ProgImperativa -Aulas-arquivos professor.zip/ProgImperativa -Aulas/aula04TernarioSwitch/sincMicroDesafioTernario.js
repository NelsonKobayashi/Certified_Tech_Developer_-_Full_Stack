// Aula 04 -assincSwitchExtra09 - assíncrono
// CondicionaL - SWITCH


function podeSubir(altura) {
    return altura >=1.40 && altura <=2.00 ? console.log("acesso permitido") : 
    console.log("acesso negado")
}

podeSubir(1.00)

