// Aula 03 -Ex01 - assíncrono
// CondicionaL - IF TERNÁRIO

// condição ? expressão para true : 
// declaração para o false;

let oMaior = 4 > 10 ? "O 4 é maior" : "O 10 é maior";

console.log(oMaior); // O 10 é maior


