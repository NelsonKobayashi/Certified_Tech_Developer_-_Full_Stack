// Aula 04 -assincExtra09IF.js
// CondicionaL - IF

let idade = 18

if(idade >= 18) {
    console.log("Maior de idade")
} else {
    console.log("Menor de idade")
}