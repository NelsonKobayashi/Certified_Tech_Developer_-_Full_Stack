// Aula 04 -assincSwitchExtra09 - assíncrono
// CondicionaL - SWITCH

let dinheiro = 13

if(dinheiro >= 20) {
    console.log("Vou lavar no Lava Jato");
} else if (dinheiro >= 10 && dinheiro <= 20){
    console.log("Vou lavar em casa, mesmo")
} else {
    console.log("Deixa chover, kkkk")
}