// Aula 04 - assincIfTernarioEx07.js
// CondicionaL - IF TERNÁRIO

// condição ? expressão para true : 
// declaração para o false;

let dia = "feriado";
let resultado = dia == "feriado"? "Vou a praia":"Vou estudar"; 

console.log(resultado);



