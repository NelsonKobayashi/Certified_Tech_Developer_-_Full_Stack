// Aula 03 -Ex01 - assíncrono
// Condicionais - IF e Operador &&

let clima = "ensolarado";
let dia = "domingo";

if(clima == "ensolarado" && dia == "domingo") {
    console.log("Vou para a praia");
}
else {
    console.log("Chamar amigos para tomar um café em casa");
}
