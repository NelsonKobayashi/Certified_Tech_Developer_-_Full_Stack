// Aula 03 -Ex01 - assíncrono
// CondicionaL - SWITCH

let dia = "quarta";

switch(dia) {
    case "segunda":
        console.log("Vou tomar um café reforçado");
        break;    
    case "quarta":
        console.log("Vou ao cinema!");
        break;
    default: 
        console.log("Vou estudar!");
}




