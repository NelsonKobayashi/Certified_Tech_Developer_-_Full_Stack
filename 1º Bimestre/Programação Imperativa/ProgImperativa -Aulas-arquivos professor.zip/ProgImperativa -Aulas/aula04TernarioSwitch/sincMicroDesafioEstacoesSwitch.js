// Aula 04 -assincSwitchExtra09 - assíncrono
// CondicionaL - SWITCH

let estacao = "Verão"

switch (estacao) {
    case "Verão":
    console.log("Tá quente")
    break;

    case "Inverno":
    console.log("Tá frio")
    break;

    case "Outono":
    console.log("Pegue o guarda-chuva")
    break;

    case "Primavera":
    console.log("As cerejeiras estão florindo!")
    break;

    default:
    console.log("Que estão é essa?")
}