// Aula 04 -assincSwitchExtra09 - assíncrono
// CondicionaL - SWITCH

let idade = 18
//           condicao ?   verdadeiro(if)   : falso (else)
console.log(idade >= 18 ? "Maior de idade" : "Menor de idade")
