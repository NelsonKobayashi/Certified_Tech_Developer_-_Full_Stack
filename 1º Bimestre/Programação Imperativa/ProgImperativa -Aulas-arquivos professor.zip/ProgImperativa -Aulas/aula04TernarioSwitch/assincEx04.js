// Aula 03 -Ex01 - assíncrono
// Condicionais - IF e Operador &&

let dia = "domingo";

if(dia == "domingo") {
    console.log("Vou para a praia!");
}
else if (dia == "sexta") {
    console.log("Vou para o cinema!");
}
else {
    console.log("Chamar amigos para comer uma pizz em casa!");
}
