// Aula 04 - 02/06/2021 
//Estrutura de Controle - IF / SE
let cumpriuTarefas = false;
let arrumouCama = false;

if (cumpriuTarefas == true || arrumouCama == true) {
    console.log("Muito Bem!!")
}
else {
    console.log("Volte e complete as tarefas!")
}
