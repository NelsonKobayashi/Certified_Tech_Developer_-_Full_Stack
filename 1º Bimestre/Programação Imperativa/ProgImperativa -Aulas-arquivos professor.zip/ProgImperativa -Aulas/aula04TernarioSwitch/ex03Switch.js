// Aula 04 - 08/06/2021
// ex03Switch.js

let dia = "quarta";

switch(dia) {
    case "segunda":
        console.log("Vou tomar um café reforçado");
        break;
    case "quarta":
        console.log("Vou ao Cinema!");
        break;
    default:
        console.log("Vou Estudar!");
}