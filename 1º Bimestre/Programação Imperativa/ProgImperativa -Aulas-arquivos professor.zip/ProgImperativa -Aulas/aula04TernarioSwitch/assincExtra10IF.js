// Aula 04 -assincSwitchExtra09 - assíncrono
// CondicionaL - SWITCH

let pedidoDeEmprestimo = true
let rendaMensal = 2500 // teste

if(pedidoDeEmprestimo == true && rendaMensal >= 2500) {
    //verdadeiro
    console.log("Empréstimo Liberado")
} else {
    console.log("Empréstimo negado")
}