// Aula 03 -Ex01 - assíncrono
// CondicionaL - SWITCH

let fruta = "laranja";

switch(fruta) {
    case "banana":
        console.log("Uma fruta amarela");
        break;    
    case "laranja":
        console.log("Bem ácida!");
        break;
    default: 
        console.log("Qual fruta é?");
}




