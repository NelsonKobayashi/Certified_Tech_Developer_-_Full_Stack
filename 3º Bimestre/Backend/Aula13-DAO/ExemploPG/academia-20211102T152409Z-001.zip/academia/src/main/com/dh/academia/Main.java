package main.com.dh.academia;

import main.com.dh.academia.dao.ConfiguracionJDBC;
import main.com.dh.academia.dao.impl.EstudianteDaoH2;
import main.com.dh.academia.model.Estudiante;
import main.com.dh.academia.service.EstudianteService;

public class Main {

    public static void main(String[] args) {

    }
}
