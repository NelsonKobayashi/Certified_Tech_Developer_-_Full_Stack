
create table IF NOT EXISTS estudiantes(id varchar(255),nombre varchar(255),apellido varchar (255));