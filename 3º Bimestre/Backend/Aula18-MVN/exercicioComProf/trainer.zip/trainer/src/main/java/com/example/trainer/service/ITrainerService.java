package com.example.trainer.service;

import com.example.trainer.domain.Trainer;

import java.util.List;

public interface ITrainerService {

    List<Trainer> listTrainer();
}
