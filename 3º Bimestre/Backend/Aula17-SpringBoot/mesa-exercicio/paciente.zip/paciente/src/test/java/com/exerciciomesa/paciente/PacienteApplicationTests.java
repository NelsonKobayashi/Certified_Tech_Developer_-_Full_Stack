package com.exerciciomesa.paciente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
