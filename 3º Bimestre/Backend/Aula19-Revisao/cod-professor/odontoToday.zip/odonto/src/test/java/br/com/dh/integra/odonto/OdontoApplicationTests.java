package br.com.dh.integra.odonto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontoApplicationTests {

	@Test
	void contextLoads() {
	}

}
